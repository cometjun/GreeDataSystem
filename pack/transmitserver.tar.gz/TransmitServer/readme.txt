1. src/ip.cfg -- 服务器配置
	clientport : 服务器侦听接口
2. 启动程序
	./start.sh 