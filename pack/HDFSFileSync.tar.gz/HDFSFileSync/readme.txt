1. 编辑 src/syscount.txt 文件,格式为: 系统名 + 空格 + 要上传的文件名
	ip : hdfs 的 ip 地址
2. 启动程序 
	./start.sh