/*
 * LOG.cpp
 *
 *  Created on: 2015年11月7日
 *      Author: yjunlei
 */

#include "LOG.h"

namespace server {

zlog_category_t * LOG::category = NULL;
LOG::LOG() {
	// TODO Auto-generated constructor stub

}

LOG::~LOG() {
	// TODO Auto-generated destructor stub
}

} /* namespace server */
