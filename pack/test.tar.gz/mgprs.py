#coding=utf-8
import socket, struct
import binascii
import thread
import time

def printhex(data):
        hexstr = ''
        for i in data:
            hexstr += ' ' + hex(ord(i));
        print(hexstr)
def convertTo(num,mod):
        print("91 mod : " + str(mod))
        print("mac : " + str(num))

	data90 = '10 00 10 00 00 00 01 10 00 00 00 00 00 ' + str(num) + ' 00 06 90 06 5F 00 01 41 42'
	data91 = '10 00 10 00 00 00 01 10 00 00 00 00 00 ' + str(num) + ' 00 06 91 ' + str(mod) + ' 5F 00 01 41 42'
	data = '10 00 10 00 00 00 01 10 00 00 00 00 00 ' + str(num) + ' 00 02 F3 11 66'
	ss90 = data90.split()
	ss91 = data91.split()
        ss = data.split();

	result90 = struct.pack('>H',int('7e7e',16))
	result91 = struct.pack('>H',int('7e7e',16))
	result = struct.pack('>H',int('7e7e',16))
	sendData90 = [int(c,16) for c in ss90]
	sendData91 = [int(c,16) for c in ss91]
	sendData = [int(c,16) for c in ss]



	for c in ss90:
		result90 += struct.pack('>B',int(c,16))
	for c1 in ss91:
		result91 += struct.pack('>B',int(c1,16))
	for c2 in ss:
		result += struct.pack('>B',int(c2,16))

	address = '127.0.0.1'
	port = 7103    #GPRS 7101
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.connect((address, port))
	s.send(result90)
	s.send(result91)
	i = 0;
	while True:
		len = s.send(result)
                time.sleep(1)
        # da = s.recv(30)
        # print("%s data" % da)

def mutiThread(count):
    i = 0
    while i < count/2:
	thread.start_new_thread(convertTo,(i,03))
        i = i + 1
    while i < count:
	thread.start_new_thread(convertTo,(i,00))
        i = i + 1
if __name__ == '__main__':
    mutiThread(1)
    input("press enter to exit")
